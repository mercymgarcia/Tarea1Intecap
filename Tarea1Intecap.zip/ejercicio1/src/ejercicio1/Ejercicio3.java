/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

import java.util.Scanner;

/**
 *
 * @author Sonia
 */
public class Ejercicio3 {
    public static void main(String[] args) {
        float num1;
        int num2=2;
        int num3=3;
        float result;
        float resultt;
        int opcion= 0;
        // TODO code application logic here
        do{
            Scanner scanner = new Scanner(System.in);
            System.out.println("ingrese un numero");
            num1 = scanner.nextFloat ();
            result = num1*num2;
            resultt = num1*num3;
            System.out.println("El doble es:" + result);
            System.out.println("El triple es:" + resultt);
            
        }while (opcion==1);
    }
}
