/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio1;

import java.util.Scanner;

/**
 *
 * @author Sonia
 */
public class Ejercicio1 {

public static void main(String[] args) {
        // TODO code application logic here
        int numero1=1;
        int numero2=3;        
        System.out.println(numero1);
        System.out.println(numero2);
        
}
    
}
