/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

import java.util.Scanner;

/**
 *
 * @author Sonia
 */
public class Ejercicio4 {
         public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
         double gradosCen, gradosFar;
         System.out.println ("Introduce grados Centigrados: ");
         gradosCen = sc.nextDouble();
         gradosFar = 32 + (9 * gradosCen / 5);
         System.out.println(gradosCen + " °C = " + gradosFar + " °F");
    }
}
