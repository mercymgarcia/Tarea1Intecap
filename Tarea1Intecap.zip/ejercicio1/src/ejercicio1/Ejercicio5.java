/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

import java.util.Scanner;

/**
 *
 * @author Sonia
 */
public class Ejercicio5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double radio, longitud, area;
        System.out.println("Introduce el radio de la circunferencia: ");
        radio = sc.nextDouble();
        area = 3.141516 * Math.pow(radio, 2);
        longitud = 2 * 3.141516 * radio;
        System.out.println("Su Longitud es: " + longitud);
        System.out.println("Su Area es: " + area);
     }    
}
